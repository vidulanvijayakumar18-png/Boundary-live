# Boundary Live — Cricket

A responsive cricket-score website/PWA with live-score refresh, upcoming-match view, search, and browser notifications for score changes while the app is open.

## Important data note
The app starts in clearly labelled demo mode. It does not invent current scores. To display live scores, configure a CricketData API key on the server. API plans and endpoint availability can change. The included basic integration uses `https://api.cricapi.com/v1/currentMatches` and `/matches`; verify the current plan supports the endpoints you need at https://cricketdata.org/ before relying on it. Official tournament points tables/rankings need a standings-capable endpoint and are intentionally not fabricated in this starter.

## Run on a computer
1. Install Node.js 18 or newer from https://nodejs.org/
2. Unzip this folder.
3. Open a terminal inside the `BoundaryLive` folder and run `npm install`.
4. Set your API key as an environment variable (keep it private):
   - Windows PowerShell: `$env:CRICKETDATA_API_KEY="YOUR_KEY_HERE"`
   - macOS/Linux: `export CRICKETDATA_API_KEY="YOUR_KEY_HERE"`
5. Run `npm start` and open `http://localhost:3000`.

Do not paste the API key into `public/index.html` or share it publicly. For public hosting, use a server host that supports environment variables and HTTPS.

## Add it to an Android phone
1. Deploy the Node app to a HTTPS host that supports Node.js and environment variables.
2. Open the deployed website in Chrome on Android.
3. Open Chrome menu (⋮) → **Add to Home screen** or **Install app**.
4. The app icon appears on your home screen and it opens in an app-like window.

This creates an installable web app (PWA), not a signed APK. A standalone APK requires an Android wrapper/build step (for example, Capacitor) and Android Studio; this ZIP does not pretend an APK has already been built.

## Features and current limits
- Live scores: refreshes every 60 seconds when API is configured.
- Upcoming matches: uses the provider's match list; check provider docs for whether that endpoint means upcoming fixtures for your plan.
- Notifications: browser permission required; score-change notifications work while the page is open. They are not guaranteed background/push notifications.
- Search: searches the loaded match data.
- Points table/rankings: interface included, but needs a compatible tournament standings/rankings API endpoint to show official standings.
- Service worker caches the app shell for a basic offline launch; live data still requires internet.

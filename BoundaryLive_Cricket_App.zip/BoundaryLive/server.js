const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.CRICKETDATA_API_KEY || "";
const API_BASE = "https://api.cricapi.com/v1";

app.use(express.static(path.join(__dirname, "public")));

async function provider(pathname) {
  if (!API_KEY) {
    return { configured: false, message: "Add CRICKETDATA_API_KEY on the server to enable live cricket data." };
  }
  const url = new URL(API_BASE + pathname);
  url.searchParams.set("apikey", API_KEY);
  url.searchParams.set("offset", "0");
  const response = await fetch(url, { headers: { "Accept": "application/json" } });
  if (!response.ok) throw new Error(`Cricket data provider returned HTTP ${response.status}`);
  return await response.json();
}

app.get("/api/live", async (_req, res) => {
  try {
    const data = await provider("/currentMatches");
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: "Could not load live scores.", detail: e.message });
  }
});

app.get("/api/upcoming", async (_req, res) => {
  try {
    const data = await provider("/matches");
    res.json(data);
  } catch (e) {
    res.status(502).json({ error: "Could not load upcoming matches.", detail: e.message });
  }
});

app.get("/api/status", (_req, res) => {
  res.json({ configured: Boolean(API_KEY), app: "Boundary Live" });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Boundary Live running at http://localhost:${PORT}`));
